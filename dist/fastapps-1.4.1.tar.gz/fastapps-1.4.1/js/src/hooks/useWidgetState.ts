import { useCallback, useEffect, useState, type SetStateAction } from "react";
import { useOpenAiGlobal } from "./useOpenaiGlobal";
import type { UnknownObject } from "./types";

/**
 * Hook to manage widget state with ChatGPT.
 * 
 * Similar to useState, but persists state in ChatGPT.
 * 
 * @param defaultState - The default state value
 * @returns A tuple of [state, setState]
 * 
 * @example
 * ```tsx
 * import { useWidgetState } from 'fastapps';
 * 
 * export default function Counter() {
 *   const [count, setCount] = useWidgetState({ value: 0 });
 *   
 *   return (
 *     <button onClick={() => setCount({ value: count.value + 1 })}>
 *       Count: {count?.value || 0}
 *     </button>
 *   );
 * }
 * ```
 */
export function useWidgetState<T extends UnknownObject>(
  defaultState: T | (() => T)
): readonly [T, (state: SetStateAction<T>) => void];
export function useWidgetState<T extends UnknownObject>(
  defaultState?: T | (() => T | null) | null
): readonly [T | null, (state: SetStateAction<T | null>) => void];
export function useWidgetState<T extends UnknownObject>(
  defaultState?: T | (() => T | null) | null
): readonly [T | null, (state: SetStateAction<T | null>) => void] {
  const widgetStateFromWindow = useOpenAiGlobal("widgetState") as T;

  const [widgetState, _setWidgetState] = useState<T | null>(() => {
    if (widgetStateFromWindow != null) {
      return widgetStateFromWindow;
    }

    return typeof defaultState === "function"
      ? defaultState()
      : defaultState ?? null;
  });

  useEffect(() => {
    _setWidgetState(widgetStateFromWindow);
  }, [widgetStateFromWindow]);

  const setWidgetState = useCallback(
    (state: SetStateAction<T | null>) => {
      _setWidgetState((prevState) => {
        const newState = typeof state === "function" ? state(prevState) : state;

        if (newState != null) {
          window.openai.setWidgetState(newState);
        }

        return newState;
      });
    },
    [window.openai.setWidgetState]
  );

  return [widgetState, setWidgetState] as const;
}

