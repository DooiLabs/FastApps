"""CLI module for Flick framework."""

from .main import cli

__all__ = ["cli"]
