"""Type definitions for Flick framework."""

from .schema import ConfigDict, Field

__all__ = ["Field", "ConfigDict"]
